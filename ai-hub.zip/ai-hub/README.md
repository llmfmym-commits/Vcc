# مرکز هوش مصنوعی (AI Hub)

اپلیکیشن وب جامع برای دسترسی به چند هوش مصنوعی (ChatGPT، Claude، Gemini، DeepSeek، Grok، Copilot، Google AI Studio، Nano-to-Nano و...) در یک رابط واحد شبیه اپلیکیشن، با پشتیبانی کامل از راست‌به‌چپ (فارسی)، تم شب/روز، تبلیغ بین‌صفحه‌ای قبل از ورود، و مسیر آماده تبدیل به اپلیکیشن اندروید با **Kotlin (Capacitor)**.

## ساختار پروژه

```
ai-hub/
├── index.html          صفحه اصلی (داشبورد، منو، دسته‌بندی، تبلیغ، اجرا)
├── css/style.css        تمام استایل‌ها (تم روشن/تاریک با CSS variables)
├── js/
│   ├── data.js           لیست هوش‌مصنوعی‌ها و دسته‌بندی‌ها (منبع اصلی داده)
│   ├── i18n.js            رشته‌های فارسی/انگلیسی
│   ├── icons.js           آیکن‌های SVG داخلی
│   ├── ads.js              مدیریت نمایش تبلیغ بین‌صفحه‌ای
│   └── app.js               منطق اصلی و رندر رابط کاربری
├── android/               پروژه اندروید (Kotlin) — نیاز به تکمیل با Capacitor CLI
│   └── app/src/main/java/com/aihub/app/
│       ├── MainActivity.kt   اکتیویتی اصلی (WebView از طریق Capacitor)
│       └── AdsPlugin.kt        پلاگین نمونه برای اتصال تبلیغات بومی
├── capacitor.config.json
├── package.json
└── .github/workflows/deploy.yml   اجرای خودکار (CI) در گیت‌هاب
```

## ۱) اجرای نسخه وب

هر سرور استاتیک کافی است:

```bash
npx http-server . -p 8080
# یا
python3 -m http.server 8080
```

سپس `http://localhost:8080` را باز کنید.

## ۲) تبدیل به اپلیکیشن اندروید (Kotlin) با Capacitor

پوشه `android/` شامل فایل‌های سفارشی (Kotlin، Manifest، Gradle) است، اما فایل‌های تولیدی Capacitor (گریدل-رَپِر، `capacitor.build.gradle` و غیره) باید یک‌بار توسط خود CLI ساخته شوند:

```bash
npm install
npx cap init "مرکز هوش مصنوعی" com.aihub.app --web-dir "."
npx cap add android      # فایل‌های تولیدی گریدل را می‌سازد و با android/ موجود ادغام می‌کند
npx cap sync android
npx cap open android     # باز شدن در Android Studio برای اجرا/بیلد APK
```

> نکته: چون `android/` از قبل با فایل‌های Kotlin سفارشی (`MainActivity.kt`, `AdsPlugin.kt`) در پروژه شما وجود دارد، دستور `cap add android` این پوشه را تشخیص داده و فقط فایل‌های گریدلی لازم (wrapper و غیره) را کامل می‌کند؛ محتوای Kotlin شما دست‌نخورده می‌ماند.

### اتصال تبلیغات بومی (Tapsell / Adivery / AdMob)

1. در `android/app/build.gradle` وابستگی SDK مورد نظر را از حالت کامنت خارج کنید.
2. در `AdsPlugin.kt`، داخل متد `showInterstitial`، طبق مستندات همان SDK تبلیغ را لود و نمایش دهید و در پایان `call.resolve()` را صدا بزنید.
3. در `js/ads.js` (تابع `showAd`)، خط زیر از حالت کامنت خارج شود تا هنگام اجرای اپلیکیشن اندروید، به‌جای شمارش معکوس نمایشی، تبلیغ واقعی نمایش داده شود:
   ```js
   if (window.Capacitor?.Plugins?.AdsPlugin) {
     window.Capacitor.Plugins.AdsPlugin.showInterstitial().then(onComplete);
     return;
   }
   ```

### اتصال تبلیغات وب (Google AdSense)

اسکریپت AdSense را در `<head>` فایل `index.html` (محل مشخص‌شده با کامنت) قرار دهید و داخل `#adSlot` در همان فایل، تگ `<ins class="adsbygoogle">` را اضافه کنید.

## ۳) افزودن هوش مصنوعی جدید

فقط کافیست یک آبجکت جدید به آرایه `AI_LIST` در `js/data.js` اضافه کنید (نام، دسته‌بندی، سطح قیمت، لینک). بقیه رابط کاربری (ردیف‌ها، صفحه دسته‌بندی، جستجو) به‌صورت خودکار به‌روزرسانی می‌شود.

## ۴) یکپارچه‌سازی مداوم (CI)

فایل `.github/workflows/deploy.yml` نسخه وب را به‌صورت خودکار روی **GitHub Pages** منتشر می‌کند (با هر push به شاخه `main`). ساخت خودکار APK اندروید به دلیل نیاز به فایل‌های تولیدی Capacitor و امضای اپلیکیشن، به‌صورت دستی (`workflow_dispatch`) در همان فایل قرار داده شده و نیاز به تنظیم Secrets (کلید امضا) دارد.
