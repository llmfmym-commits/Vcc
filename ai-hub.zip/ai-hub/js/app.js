/** منطق اصلی برنامه: رندر صفحات، ناوبری، تم/زبان، صفحه دسته‌بندی، اجرای هوش مصنوعی */

const AppState = {
  theme: localStorage.getItem("aihub_theme") || "light",
  lang: localStorage.getItem("aihub_lang") || "fa",
  computerMode: false,
  currentCategory: null,
  catFilter: "all",
  catQuery: ""
};

const $ = (sel, root) => (root || document).querySelector(sel);
const $all = (sel, root) => Array.from((root || document).querySelectorAll(sel));

document.addEventListener("DOMContentLoaded", () => {
  AdManager.init();
  applyTheme(AppState.theme, false);
  applyLang(AppState.lang, false);
  renderIcons();
  renderHomeRows();
  bindGlobalEvents();
});

function applyTheme(theme, persist = true) {
  AppState.theme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  if (persist) localStorage.setItem("aihub_theme", theme);
}
function toggleTheme() { applyTheme(AppState.theme === "light" ? "dark" : "light"); }

function applyLang(lang, persist = true) {
  AppState.lang = lang;
  const html = document.documentElement;
  html.lang = lang;
  html.dir = lang === "fa" ? "rtl" : "ltr";
  const t = I18N[lang];

  $all("[data-i18n]").forEach(el => { const key = el.getAttribute("data-i18n"); if (t[key]) el.textContent = t[key]; });

  $("#topbarTitleText").textContent = t.appTitle;
  $("#guestUserText").textContent = t.guestUser;
  $("#welcomeText").textContent = t.welcome;
  $("#premiumText").textContent = t.premiumTitle;
  $("#upgradeText").innerHTML = t.upgrade + ' <span class="crown">👑</span>';
  $("#langBtn").textContent = lang === "fa" ? "FA" : "EN";
  $("#catSearchInput").placeholder = t.search;
  AdManager.applyLang(t);

  if (persist) localStorage.setItem("aihub_lang", lang);

  renderHomeRows();
  if (AppState.currentCategory) openCategory(AppState.currentCategory.id, false);
}

function bindGlobalEvents() {
  $("#menuBtn").addEventListener("click", openDrawer);
  $("#overlay").addEventListener("click", closeDrawer);
  $("#themeBtn").addEventListener("click", toggleTheme);
  $("#langBtn").addEventListener("click", () => applyLang(AppState.lang === "fa" ? "en" : "fa"));

  $all("#computerModeBtn, #catComputerBtn, #runnerComputerBtn").forEach(btn => btn.addEventListener("click", toggleComputerMode));

  $("#catBackBtn").addEventListener("click", closeCategory);
  $("#catCloseBtn").addEventListener("click", closeCategory);

  $("#catSearchInput").addEventListener("input", e => { AppState.catQuery = e.target.value.trim(); renderCategoryList(); });

  $("#runnerExitBtn").addEventListener("click", closeRunner);

  $all(".bn-item").forEach(btn => {
    btn.addEventListener("click", () => {
      $all(".bn-item").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const target = btn.getAttribute("data-bn");
      if (target === "dashboard") closeCategory();
      else if (target !== "profile") openCategory(target);
    });
  });

  $("#drawerNav").addEventListener("click", e => {
    const a = e.target.closest("a[data-nav]");
    if (!a) return;
    e.preventDefault();
    closeDrawer();
    const nav = a.getAttribute("data-nav");
    if (nav === "dashboard") { closeCategory(); return; }
    if (["chat", "image", "video", "audio", "music", "model3d", "recent"].includes(nav)) openCategory(nav);
  });
}

function toggleComputerMode() {
  AppState.computerMode = !AppState.computerMode;
  document.body.classList.toggle("computer-mode", AppState.computerMode);
  $all("#computerModeBtn, #catComputerBtn, #runnerComputerBtn").forEach(btn => btn.setAttribute("data-active", String(AppState.computerMode)));
}

function openDrawer() { $("#drawer").classList.add("open"); $("#overlay").classList.add("show"); }
function closeDrawer() { $("#drawer").classList.remove("open"); $("#overlay").classList.remove("show"); }

function renderHomeRows() {
  const t = I18N[AppState.lang];
  const container = $("#rowsContainer");
  container.innerHTML = "";

  HOME_ROWS.forEach(row => {
    const items = row.filter(AI_LIST);
    if (items.length === 0) return;
    const title = AppState.lang === "fa" ? row.titleFa : row.titleEn;
    const section = document.createElement("section");
    section.className = "hrow";
    section.innerHTML = `<div class="hrow-head"><h2><i data-icon="${row.icon}"></i> ${title}</h2></div><div class="hrow-track"></div>`;
    const track = section.querySelector(".hrow-track");
    items.slice(0, 8).forEach(ai => track.appendChild(buildAiCard(ai)));

    if (items.length > 4) {
      const viewAll = document.createElement("button");
      viewAll.className = "ai-card view-all-card";
      viewAll.setAttribute("aria-label", t.viewAll);
      viewAll.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg><span>${t.viewAll}</span>`;
      viewAll.addEventListener("click", () => openCategory(row.id));
      track.appendChild(viewAll);
    }
    container.appendChild(section);
  });

  renderIcons(container);
  $all(".ai-card", container).forEach(bindCardTouch);
}

function buildAiCard(ai) {
  const t = I18N[AppState.lang];
  const name = AppState.lang === "fa" ? ai.nameFa : ai.name;
  const card = document.createElement("button");
  card.className = "ai-card";
  card.innerHTML = `<span class="ai-icon ${ai.logo}">${ai.symbol}</span><span class="ai-name">${name}</span><span class="ai-sub">${t[CONTENT_TYPES[ai.type].icon] || t[ai.type] || ""}</span>`;
  card.addEventListener("click", () => startAdFlow(ai));
  return card;
}

function bindCardTouch(card) {
  card.addEventListener("touchstart", () => card.classList.add("tapped"), { passive: true });
  card.addEventListener("touchend", () => setTimeout(() => card.classList.remove("tapped"), 150));
}

function openCategory(rowOrTypeId, animate = true) {
  const t = I18N[AppState.lang];
  let list, title;
  const row = HOME_ROWS.find(r => r.id === rowOrTypeId);
  if (row) { list = row.filter(AI_LIST); title = AppState.lang === "fa" ? row.titleFa : row.titleEn; }
  else if (rowOrTypeId === "recent") { list = AI_LIST.filter(a => a.recent); title = t.recentMenu; }
  else if (CONTENT_TYPES[rowOrTypeId]) { list = AI_LIST.filter(a => a.type === rowOrTypeId); title = CONTENT_TYPES[rowOrTypeId][AppState.lang]; }
  else { list = AI_LIST; title = t.appTitle; }

  AppState.currentCategory = { id: rowOrTypeId, title, list };
  AppState.catFilter = "all";
  AppState.catQuery = "";
  $("#catSearchInput").value = "";
  $("#catTitle").textContent = title;

  renderCatChips();
  renderCategoryList();

  $("#categoryPage").hidden = false;
  requestAnimationFrame(() => $("#categoryPage").classList.add("open"));
  document.body.classList.add("no-scroll");
}

function closeCategory() {
  $("#categoryPage").classList.remove("open");
  setTimeout(() => { $("#categoryPage").hidden = true; }, 220);
  document.body.classList.remove("no-scroll");
  AppState.currentCategory = null;
  $all(".bn-item").forEach(b => b.classList.remove("active"));
  $('.bn-item[data-bn="dashboard"]').classList.add("active");
}

function renderCatChips() {
  const t = I18N[AppState.lang];
  const chips = $("#catChips");
  const types = ["all", "video", "image", "audio", "chat", "music", "model3d"];
  chips.innerHTML = types.map(id => {
    const label = id === "all" ? t.all : (CONTENT_TYPES[id] ? CONTENT_TYPES[id][AppState.lang] : id);
    return `<button class="chip ${AppState.catFilter === id ? "active" : ""}" data-chip="${id}">${label}</button>`;
  }).join("") + `<button class="chip chip-icon" title="${t.filters}"><i data-icon="filter"></i></button>`;

  renderIcons(chips);
  $all(".chip[data-chip]", chips).forEach(chip => {
    chip.addEventListener("click", () => { AppState.catFilter = chip.getAttribute("data-chip"); renderCatChips(); renderCategoryList(); });
  });
}

function renderCategoryList() {
  const t = I18N[AppState.lang];
  const wrap = $("#catList");
  if (!AppState.currentCategory) return;

  let list = AppState.currentCategory.list;
  if (AppState.catFilter !== "all") list = list.filter(a => a.type === AppState.catFilter);
  if (AppState.catQuery) {
    const q = AppState.catQuery.toLowerCase();
    list = list.filter(a => a.name.toLowerCase().includes(q) || a.nameFa.includes(AppState.catQuery));
  }

  if (list.length === 0) { wrap.innerHTML = `<div class="cat-empty">${t.empty}</div>`; return; }

  wrap.innerHTML = list.map(ai => {
    const name = AppState.lang === "fa" ? ai.nameFa : ai.name;
    const desc = AppState.lang === "fa" ? ai.descFa : ai.descEn;
    const pricing = PRICING[ai.pricing];
    const badgeLabel = AppState.lang === "fa" ? pricing.fa : pricing.en;
    return `<button class="cat-item" data-id="${ai.id}">
        <span class="ai-icon ${ai.logo}">${ai.symbol}</span>
        <span class="cat-item-info">
          <span class="cat-item-top"><span class="cat-item-name">${name}</span><span class="badge badge-${pricing.badge}">${badgeLabel}</span></span>
          <span class="cat-item-desc">${desc}</span>
        </span>
        <span class="chevron">${AppState.lang === "fa" ? "‹" : "›"}</span>
      </button>`;
  }).join("");

  $all(".cat-item", wrap).forEach(item => {
    item.addEventListener("click", () => { const ai = AI_LIST.find(a => a.id === item.getAttribute("data-id")); if (ai) startAdFlow(ai); });
  });
}

function startAdFlow(ai) { markRecent(ai); AdManager.showAd(ai, () => openRunner(ai)); }
function markRecent(ai) { ai.recent = true; }

function openRunner(ai) {
  const name = AppState.lang === "fa" ? ai.nameFa : ai.name;
  $("#runnerTitle").textContent = name;
  $("#runnerFrame").src = ai.url === "#" ? "about:blank" : ai.url;
  $("#aiRunner").hidden = false;
  document.body.classList.add("no-scroll");
}
function closeRunner() { $("#aiRunner").hidden = true; $("#runnerFrame").src = "about:blank"; document.body.classList.remove("no-scroll"); }
