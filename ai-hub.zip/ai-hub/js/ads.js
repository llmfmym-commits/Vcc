/**
 * مدیریت نمایش تبلیغ بین‌صفحه‌ای پیش از باز شدن هر هوش مصنوعی.
 *
 * اتصال شبکه‌های تبلیغاتی واقعی — راهنما در README.md:
 *  - وب: Google AdSense داخل #adSlot
 *  - اندروید (Kotlin/Capacitor): پلاگین Tapsell/Adivery/AdMob از طریق window.Capacitor.Plugins
 */
const AdManager = (() => {
  const AD_DURATION_SECONDS = 5;
  let modalEl, appIconEl, appNameEl, progressBar, skipBtn, skipCounter, skipText, loadingText;
  let timerId = null;
  let onCompleteCb = null;

  function init() {
    modalEl = document.getElementById("adModal");
    appIconEl = document.getElementById("adAppIcon");
    appNameEl = document.getElementById("adAppName");
    progressBar = document.getElementById("adProgressBar");
    skipBtn = document.getElementById("adSkipBtn");
    skipCounter = document.getElementById("adSkipCounter");
    skipText = document.getElementById("adSkipText");
    loadingText = document.getElementById("adLoadingText");
    skipBtn.addEventListener("click", () => { if (!skipBtn.disabled) finish(); });
  }

  function showAd(ai, onComplete) {
    onCompleteCb = onComplete;
    appIconEl.textContent = ai.symbol || "✦";
    appIconEl.className = "ad-app-icon " + (ai.logo || "");
    appNameEl.textContent = (document.documentElement.lang === "en") ? ai.name : ai.nameFa;

    // نقطه اتصال SDK بومی اندروید (Kotlin) از طریق Capacitor Plugin در اینجا:
    // if (window.Capacitor?.Plugins?.TapsellAds) { window.Capacitor.Plugins.TapsellAds.showInterstitial(); }

    modalEl.hidden = false;
    document.body.classList.add("no-scroll");

    let remaining = AD_DURATION_SECONDS;
    skipBtn.disabled = true;
    updateSkipLabel(remaining);
    progressBar.style.width = "0%";

    clearInterval(timerId);
    timerId = setInterval(() => {
      remaining -= 1;
      const pct = Math.min(100, ((AD_DURATION_SECONDS - remaining) / AD_DURATION_SECONDS) * 100);
      progressBar.style.width = pct + "%";
      if (remaining <= 0) {
        clearInterval(timerId);
        skipBtn.disabled = false;
        updateSkipLabel(0);
      } else {
        updateSkipLabel(remaining);
      }
    }, 1000);
  }

  function updateSkipLabel(remaining) {
    if (remaining > 0) { skipCounter.textContent = `(${remaining})`; skipBtn.classList.remove("ready"); }
    else { skipCounter.textContent = ""; skipBtn.classList.add("ready"); }
  }

  function finish() {
    clearInterval(timerId);
    modalEl.hidden = true;
    document.body.classList.remove("no-scroll");
    const cb = onCompleteCb;
    onCompleteCb = null;
    if (cb) cb();
  }

  function applyLang(t) {
    if (loadingText) loadingText.textContent = t.loadingAd;
    if (skipText) skipText.textContent = t.skipAd;
  }

  return { init, showAd, applyLang };
})();
