const I18N = {
  fa: {
    appTitle: "مرکز هوش مصنوعی", dashboard: "داشبورد", chat: "چت", image: "تصویر", video: "ویدیو",
    audio: "صدا", music: "موسیقی", model3d: "مدل سه‌بعدی", favorites: "علاقه‌مندی‌ها",
    recentMenu: "انتخاب اخیر", downloads: "دانلود‌ها", settings: "تنظیمات", about: "درباره ما",
    guestUser: "کاربر مهمان", welcome: "به مرکز هوش مصنوعی خوش آمدید", premiumTitle: "نسخه پرمیوم",
    upgrade: "ارتقا دهید", viewAll: "مشاهده همه", search: "جستجو در این دسته...", all: "همه",
    filters: "فیلترها", computerMode: "حالت رایانه", mobileMode: "حالت گوشی", exit: "خروج",
    profile: "پروفایل", loadingAd: "در حال بارگذاری تبلیغ...", skipAd: "رد کردن تبلیغ",
    continue: "ورود به هوش مصنوعی", freeFull: "کاملاً رایگان", freeLimited: "با محدودیت رایگان",
    paidFull: "کاملاً پولی", empty: "موردی در این بخش یافت نشد.", back: "بازگشت"
  },
  en: {
    appTitle: "AI Hub", dashboard: "Dashboard", chat: "Chat", image: "Image", video: "Video",
    audio: "Audio", music: "Music", model3d: "3D Model", favorites: "Favorites",
    recentMenu: "Recently Used", downloads: "Downloads", settings: "Settings", about: "About",
    guestUser: "Guest User", welcome: "Welcome to the AI Hub", premiumTitle: "Premium Version",
    upgrade: "Upgrade", viewAll: "View All", search: "Search this category...", all: "All",
    filters: "Filters", computerMode: "Desktop Mode", mobileMode: "Mobile Mode", exit: "Exit",
    profile: "Profile", loadingAd: "Loading ad...", skipAd: "Skip Ad",
    continue: "Open AI Tool", freeFull: "Fully Free", freeLimited: "Limited Free",
    paidFull: "Fully Paid", empty: "Nothing found in this section.", back: "Back"
  }
};
