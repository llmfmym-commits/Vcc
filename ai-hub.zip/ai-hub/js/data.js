/**
 * داده‌های مرکزی برنامه: لیست هوش‌مصنوعی‌ها، دسته‌بندی‌ها و متن‌ها
 * این فایل تنها منبع داده است — برای افزودن هوش مصنوعی جدید فقط اینجا را ویرایش کنید.
 */

const CONTENT_TYPES = {
  chat:  { fa: "چت",   en: "Chat",  icon: "chat" },
  image: { fa: "تصویر", en: "Image", icon: "image" },
  video: { fa: "ویدیو", en: "Video", icon: "video" },
  audio: { fa: "صدا",   en: "Audio", icon: "audio" },
  music: { fa: "موسیقی", en: "Music", icon: "music" },
  model3d:{ fa: "مدل سه‌بعدی", en: "3D Model", icon: "cube" }
};

const PRICING = {
  free:    { fa: "کاملاً رایگان",     en: "Fully Free",    badge: "free" },
  limited: { fa: "با محدودیت رایگان", en: "Free (Limited)", badge: "limited" },
  paid:    { fa: "کاملاً پولی",       en: "Fully Paid",     badge: "paid" }
};

const AI_LIST = [
  { id: "chatgpt", name: "ChatGPT", nameFa: "چت جی‌پی‌تی", type: "chat", pricing: "limited", logo: "logo-chatgpt", symbol: "✦",
    descFa: "مدل پیشرفته OpenAI برای گفتگو و پاسخ به سوالات", descEn: "OpenAI's advanced conversational model",
    url: "https://chat.openai.com", recent: true, popular: true },
  { id: "claude", name: "Claude", nameFa: "کلود", type: "chat", pricing: "limited", logo: "logo-claude", symbol: "✺",
    descFa: "دستیار هوشمند Anthropic با درک عمیق و دقیق", descEn: "Anthropic's assistant with deep, careful reasoning",
    url: "https://claude.ai", recent: true, popular: true },
  { id: "gemini", name: "Gemini", nameFa: "جمینای", type: "chat", pricing: "limited", logo: "logo-gemini", symbol: "✧",
    descFa: "مدل قدرتمند گوگل برای کمک هوشمندانه", descEn: "Google's powerful assistant model",
    url: "https://gemini.google.com", recent: true, popular: true },
  { id: "deepseek", name: "DeepSeek", nameFa: "دیپ‌سیک", type: "chat", pricing: "free", logo: "logo-deepseek", symbol: "◐",
    descFa: "مدل پیشرفته برای تحلیل و مکالمه هوشمند", descEn: "Advanced model for analysis and smart conversation",
    url: "https://chat.deepseek.com", recent: true, popular: false },
  { id: "grok", name: "Grok", nameFa: "گروک", type: "chat", pricing: "limited", logo: "logo-grok", symbol: "✕",
    descFa: "هوش مصنوعی پیشرفته از xAI", descEn: "xAI's advanced conversational model",
    url: "https://grok.x.ai", recent: false, popular: true },
  { id: "copilot", name: "Microsoft Copilot", nameFa: "مایکروسافت کپایلوت", type: "chat", pricing: "limited", logo: "logo-copilot", symbol: "◈",
    descFa: "دستیار هوشمند مایکروسافت برای بهره‌وری بیشتر", descEn: "Microsoft's assistant for everyday productivity",
    url: "https://copilot.microsoft.com", recent: false, popular: false },
  { id: "aistudio", name: "Google AI Studio", nameFa: "گوگل ای‌آی استودیو", type: "chat", pricing: "free", logo: "logo-aistudio", symbol: "◆",
    descFa: "ابزار ساخت، تست و نمونه‌سازی مدل‌های هوش مصنوعی", descEn: "Build, test and prototype AI models",
    url: "https://aistudio.google.com", recent: false, popular: false },
  { id: "nano2nano", name: "Nano-to-Nano", nameFa: "نانو به نانو", type: "image", pricing: "free", logo: "logo-nano", symbol: "◎",
    descFa: "مدل تعویض و ویرایش تصویر با هوش مصنوعی", descEn: "AI-powered image editing and transformation",
    url: "#", recent: false, popular: false },
  { id: "midjourney", name: "Midjourney", nameFa: "میدجرنی", type: "image", pricing: "paid", logo: "logo-midjourney", symbol: "✹",
    descFa: "تولید تصاویر هنری با کیفیت بالا", descEn: "High-quality artistic image generation",
    url: "https://midjourney.com", recent: false, popular: false },
  { id: "runway", name: "Runway", nameFa: "رانوی", type: "video", pricing: "limited", logo: "logo-runway", symbol: "▶",
    descFa: "ساخت و ویرایش ویدیو با هوش مصنوعی", descEn: "AI video generation and editing",
    url: "https://runwayml.com", recent: false, popular: false },
  { id: "elevenlabs", name: "ElevenLabs", nameFa: "الون‌لبز", type: "audio", pricing: "limited", logo: "logo-eleven", symbol: "((·))",
    descFa: "تبدیل متن به گفتار طبیعی و دوبله هوشمند", descEn: "Natural text-to-speech and AI dubbing",
    url: "https://elevenlabs.io", recent: false, popular: false },
  { id: "suno", name: "Suno", nameFa: "سونو", type: "music", pricing: "limited", logo: "logo-suno", symbol: "♪",
    descFa: "ساخت آهنگ و موسیقی با هوش مصنوعی", descEn: "AI-generated songs and music",
    url: "https://suno.com", recent: false, popular: false },
  { id: "meshy", name: "Meshy", nameFa: "مشی", type: "model3d", pricing: "limited", logo: "logo-meshy", symbol: "⬡",
    descFa: "ساخت مدل سه‌بعدی از متن یا تصویر", descEn: "Generate 3D models from text or image",
    url: "https://meshy.ai", recent: false, popular: false },
  { id: "gpt-plus", name: "ChatGPT Plus", nameFa: "چت جی‌پی‌تی پلاس", type: "chat", pricing: "paid", logo: "logo-chatgpt", symbol: "✦",
    descFa: "نسخه پیشرفته و کامل ChatGPT", descEn: "The full, advanced version of ChatGPT",
    url: "https://chat.openai.com", recent: false, popular: false },
  { id: "claude-pro", name: "Claude Pro", nameFa: "کلود پرو", type: "chat", pricing: "paid", logo: "logo-claude", symbol: "✺",
    descFa: "نسخه حرفه‌ای Claude با امکانات بیشتر", descEn: "Claude's professional tier with more capability",
    url: "https://claude.ai", recent: false, popular: false },
  { id: "gemini-advanced", name: "Gemini Advanced", nameFa: "جمینای ادونسد", type: "chat", pricing: "paid", logo: "logo-gemini", symbol: "✧",
    descFa: "نسخه پیشرفته Gemini برای کارهای پیچیده", descEn: "Gemini's advanced tier for complex tasks",
    url: "https://gemini.google.com", recent: false, popular: false },
  { id: "grok-premium", name: "Grok Premium", nameFa: "گروک پرمیوم", type: "chat", pricing: "paid", logo: "logo-grok", symbol: "✕",
    descFa: "دسترسی کامل به قابلیت‌های Grok", descEn: "Full access to Grok's capabilities",
    url: "https://grok.x.ai", recent: false, popular: false }
];

const HOME_ROWS = [
  { id: "recent",  titleFa: "انتخاب اخیر",        titleEn: "Recently Used", icon: "clock",    filter: list => list.filter(a => a.recent) },
  { id: "popular", titleFa: "محبوب‌ترین‌ها",       titleEn: "Most Popular",  icon: "fire",      filter: list => list.filter(a => a.popular) },
  { id: "free",    titleFa: "رایگان کامل",         titleEn: "Fully Free",    icon: "gift",      filter: list => list.filter(a => a.pricing === "free") },
  { id: "limited", titleFa: "رایگان با محدودیت",   titleEn: "Free (Limited)",icon: "clock-alt", filter: list => list.filter(a => a.pricing === "limited") },
  { id: "paid",    titleFa: "کاملاً پولی",         titleEn: "Fully Paid",    icon: "crown",     filter: list => list.filter(a => a.pricing === "paid") },
  { id: "all",     titleFa: "همه هوش مصنوعی‌ها",   titleEn: "All AI Tools",  icon: "grid",      filter: list => list }
];
