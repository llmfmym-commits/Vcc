package com.aihub.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

/**
 * فعالیت اصلی اپلیکیشن اندروید — بر پایه Capacitor.
 * محتوای وب (HTML/CSS/JS) داخل WebView این اکتیویتی اجرا می‌شود،
 * و پلاگین‌های Kotlin (مثل تبلیغات) از اینجا به جاوااسکریپت متصل می‌شوند.
 */
class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // پلاگین‌های سفارشی (مثل AdsPlugin زیر) را در صورت نیاز اینجا ثبت کنید:
        // registerPlugin(AdsPlugin::class.java)
    }
}
