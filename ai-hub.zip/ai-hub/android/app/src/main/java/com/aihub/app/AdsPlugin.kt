package com.aihub.app

import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * پلاگین نمونه برای اتصال تبلیغات بومی (Tapsell / Adivery / AdMob) به جاوااسکریپت.
 *
 * نحوه استفاده در سمت جاوااسکریپت (js/ads.js):
 *   window.Capacitor.Plugins.AdsPlugin.showInterstitial()
 *
 * برای اتصال واقعی:
 *   1) SDK مورد نظر (Tapsell/Adivery/AdMob) را در android/app/build.gradle اضافه کنید.
 *   2) در متد showInterstitial، تبلیغ را طبق مستندات همان SDK لود و نمایش دهید.
 *   3) پس از پایان یا خطای تبلیغ، call.resolve() را صدا بزنید تا جاوااسکریپت ادامه یابد.
 */
@CapacitorPlugin(name = "AdsPlugin")
class AdsPlugin : Plugin() {

    @PluginMethod
    fun showInterstitial(call: PluginCall) {
        // TODO: اتصال واقعی SDK تبلیغاتی اینجا انجام شود.
        // نمونه Tapsell:
        // TapsellPlus.showInterstitialAd(activity, adId, object : AdShowListener() { ... })
        call.resolve()
    }
}
